from django.contrib import admin
from .models import WearingSession, ExercisePeriod

admin.site.register(WearingSession)    
admin.site.register(ExercisePeriod)
