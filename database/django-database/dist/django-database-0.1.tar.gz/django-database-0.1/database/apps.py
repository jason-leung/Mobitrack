from django.apps import AppConfig


class DatabaseConfig(AppConfig):
    name = 'database'
